
import React from "react";

export default function Home() {
  return (
    <div style={{fontFamily:"Arial", padding:"40px", textAlign:"center"}}>
      <h1>Centro Acadêmico Terra Livre</h1>
      <p>Seu site está pronto! Publique este projeto na Vercel para ficar online.</p>
    </div>
  );
}
